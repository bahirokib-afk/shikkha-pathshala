# শিক্ষা পাঠশালা — Starter Project

A bilingual (Bangla/English) study companion starter for Bangladesh Diploma Engineering students.

## Included now
- Responsive Modern 3D Glass-style dashboard
- Bangladesh live clock (Asia/Dhaka)
- Personal notes (currently saved in this browser/device using localStorage)
- Study focus timer and daily checklist
- Subject overview
- AI chat interface with a Cloudflare Pages Function proxy
- PWA manifest and service worker
- Light/dark mode and language toggle

## Important limitations in this starter
- Notes/tasks are local to the current browser/device. They are not yet synced between devices or user accounts.
- Login/registration, role-based admin authorization, Supabase database, syllabus/semester management, file uploads and exam engine are planned next steps, not active features yet.
- AI chat requires an OpenAI-compatible API provider and server-side environment variables. API usage may cost money and is subject to provider limits.
- Do not put API keys in `app.js`, HTML, GitHub files, or any `VITE_`/public frontend variable.

## Deploy on Cloudflare Pages (GitHub)
1. Create a GitHub repository and upload all project files/folders from this ZIP to the repository root.
2. In Cloudflare Dashboard open **Workers & Pages → Create → Pages → Connect to Git**.
3. Select the GitHub repository.
4. For this plain static project, set Build command to blank (or no build command) and Build output directory to `/` (if the dashboard requires a directory, use `.`).
5. Deploy.

## Configure AI once (server-side)
After deployment:
1. Open the Cloudflare Pages project → Settings → Variables and Secrets (or Functions environment variables).
2. Add these as **Secrets/Environment Variables** for Production (and Preview only if needed):
   - `AI_API_KEY` = your provider API key (Secret)
   - `AI_MODEL` = a model name supported by your provider (e.g. `gpt-4o-mini`, if available to your account)
   - `AI_API_URL` = optional OpenAI-compatible chat completions endpoint; omit for the default OpenAI endpoint.
3. Save and trigger a new deployment so the Function receives the variables.
4. Test AI Teacher. If the provider uses a different API format, the Function must be adapted to that provider.

The API key is entered once in Cloudflare, not by each student. Never share the key.

## Local preview
You can open `index.html` directly to preview most UI features. The `/api/chat` endpoint only works when deployed to Cloudflare Pages or run with the Cloudflare Pages development runtime.

## Next development milestone
Connect Supabase Auth + database, then migrate notes/tasks to per-user cloud storage and add real admin roles. Never grant admin access based only on a client-side flag.
