const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let lang = localStorage.getItem('sp_lang') || 'bn';
let notes = JSON.parse(localStorage.getItem('sp_notes') || '[]');
let tasks = JSON.parse(localStorage.getItem('sp_tasks') || '[]');
let questions = Number(localStorage.getItem('sp_questions') || 0);
let currentNoteId = null;
let timerSeconds = 25 * 60, timerInterval = null, timerRunning = false, selectedMinutes = 25;
let studySeconds = Number(localStorage.getItem('sp_study_seconds') || 0);
let toastTimeout;

function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>el.classList.remove('show'),2300)}
function setLanguage(next){lang=next;localStorage.setItem('sp_lang',lang);$('#lang-toggle').textContent=lang==='bn'?'বাংলা':'English';$$('[data-bn][data-en]').forEach(el=>{el.innerHTML=el.dataset[lang]});}
function showView(name){$$('.view').forEach(v=>v.classList.toggle('active',v.id===`view-${name}`));$$('.nav-item[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===name));const titles={home:lang==='bn'?'তোমার পড়াশোনার কেন্দ্র':'Your study hub',ai:'AI Teacher',notes:lang==='bn'?'আমার নোট':'My Notes',planner:lang==='bn'?'স্টাডি প্ল্যানার':'Study Planner',subjects:lang==='bn'?'বিষয়সমূহ':'Subjects',admin:lang==='bn'?'অ্যাডমিন সেটিংস':'Admin Settings'};$('#page-title').textContent=titles[name];}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.view)));
$$('[data-go]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.go)));
$('#lang-toggle').addEventListener('click',()=>setLanguage(lang==='bn'?'en':'bn'));
$('#theme-toggle').addEventListener('click',()=>{document.body.classList.toggle('light');localStorage.setItem('sp_light',document.body.classList.contains('light')?'1':'0')});
if(localStorage.getItem('sp_light')==='1')document.body.classList.add('light');
setLanguage(lang);

function updateClock(){const now=new Date();const time=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Dhaka',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(now);const date=new Intl.DateTimeFormat(lang==='bn'?'bn-BD':'en-US',{timeZone:'Asia/Dhaka',weekday:'long',year:'numeric',month:'long',day:'numeric'}).format(now);$('#main-clock').textContent=time;$('#side-clock').textContent=time;$('#main-date').textContent=date;$('#side-date').textContent=date;$('#full-date').textContent=date;const h=Number(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Dhaka',hour:'2-digit',hour12:false}).format(now));$('#today-label').textContent=h<12?'শুভ সকাল':h<17?'শুভ দুপুর':'শুভ সন্ধ্যা';}
updateClock();setInterval(updateClock,1000);

function renderNotes(filter=''){const list=$('#notes-list');list.innerHTML='';const filtered=notes.filter(n=>(n.title+n.body+n.subject).toLowerCase().includes(filter.toLowerCase()));if(!filtered.length){list.innerHTML='<div class="notice">এখনো কোনো নোট নেই। নতুন নোট তৈরি করো।</div>';return}filtered.sort((a,b)=>b.updated-a.updated).forEach(n=>{const el=document.createElement('button');el.className='note-item';el.innerHTML=`<b>${escapeHtml(n.title||'শিরোনামহীন নোট')}</b><p>${escapeHtml((n.body||'').slice(0,95))}</p><small>${escapeHtml(n.subject)} · ${new Date(n.updated).toLocaleDateString()}</small>`;el.addEventListener('click',()=>loadNote(n.id));list.appendChild(el)})}
function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function persistNotes(){localStorage.setItem('sp_notes',JSON.stringify(notes));$('#note-count').textContent=notes.length;renderNotes($('#note-search').value)}
function loadNote(id){const n=notes.find(x=>x.id===id);if(!n)return;currentNoteId=id;$('#note-title').value=n.title;$('#note-subject').value=n.subject;$('#note-body').value=n.body;$('#editor-heading').textContent='নোট সম্পাদনা';showView('notes')}
function clearEditor(){currentNoteId=null;$('#note-title').value='';$('#note-subject').value='সাধারণ';$('#note-body').value='';$('#editor-heading').textContent='নতুন নোট তৈরি'}
$('#save-note').addEventListener('click',()=>{const title=$('#note-title').value.trim(),body=$('#note-body').value.trim();if(!title&&!body){toast('আগে নোটের শিরোনাম বা লেখা দাও');return}const item={id:currentNoteId||crypto.randomUUID(),title,body,subject:$('#note-subject').value,updated:Date.now()};const i=notes.findIndex(n=>n.id===item.id);if(i>=0)notes[i]=item;else notes.push(item);persistNotes();toast('নোট এই ডিভাইসে সংরক্ষিত হয়েছে');clearEditor()});
$('#new-note').addEventListener('click',clearEditor);$('#clear-note').addEventListener('click',clearEditor);$('#note-search').addEventListener('input',e=>renderNotes(e.target.value));renderNotes();$('#note-count').textContent=notes.length;

function renderTasks(){const list=$('#task-list');list.innerHTML='';if(!tasks.length){list.innerHTML='<p class="muted">আজকের পড়ার তালিকা খালি।</p>';return}tasks.forEach(t=>{const row=document.createElement('label');row.className='task-item'+(t.done?' done':'');row.innerHTML=`<input type="checkbox" ${t.done?'checked':''}><span>${escapeHtml(t.text)}</span>`;row.querySelector('input').addEventListener('change',e=>{t.done=e.target.checked;localStorage.setItem('sp_tasks',JSON.stringify(tasks));renderTasks()});list.appendChild(row)})}
$('#task-form').addEventListener('submit',e=>{e.preventDefault();const text=$('#task-input').value.trim();if(!text)return;tasks.push({text,done:false});localStorage.setItem('sp_tasks',JSON.stringify(tasks));$('#task-input').value='';renderTasks()});renderTasks();

function formatTime(s){const m=Math.floor(s/60),sec=s%60;return `${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`}
function updateTimer(){ $('#timer-display').textContent=formatTime(timerSeconds);$('#timer-state').textContent=timerRunning?'FOCUS IN PROGRESS':'READY TO FOCUS';}
$$('.preset').forEach(b=>b.addEventListener('click',()=>{if(timerRunning)return;$$('.preset').forEach(x=>x.classList.remove('active'));b.classList.add('active');selectedMinutes=Number(b.dataset.min);timerSeconds=selectedMinutes*60;updateTimer()}));
$('#timer-start').addEventListener('click',()=>{if(timerRunning){clearInterval(timerInterval);timerRunning=false;$('#timer-start').textContent='আবার শুরু';updateTimer();return}timerRunning=true;$('#timer-start').textContent='বিরতি';updateTimer();timerInterval=setInterval(()=>{if(timerSeconds>0){timerSeconds--;studySeconds++;localStorage.setItem('sp_study_seconds',studySeconds);$('#study-total').textContent=formatTime(studySeconds);updateTimer()}else{clearInterval(timerInterval);timerRunning=false;$('#timer-start').textContent='শুরু করো';toast('ফোকাস সেশন শেষ! একটু বিরতি নাও।');updateTimer()}},1000)});
$('#timer-reset').addEventListener('click',()=>{clearInterval(timerInterval);timerRunning=false;timerSeconds=selectedMinutes*60;$('#timer-start').textContent='শুরু করো';updateTimer()});updateTimer();$('#study-total').textContent=formatTime(studySeconds);

function addMessage(text,who){const wrap=document.createElement('div');wrap.className='message '+who;const av=document.createElement('div');av.className='message-avatar';av.textContent=who==='user'?'S':'✦';const bubble=document.createElement('div');bubble.className='bubble';bubble.textContent=text;wrap.append(av,bubble);$('#chat-messages').appendChild(wrap);$('#chat-messages').scrollTop=$('#chat-messages').scrollHeight;return bubble}
async function askAI(prompt){addMessage(prompt,'user');questions++;localStorage.setItem('sp_questions',questions);$('#question-count').textContent=questions;const bubble=addMessage('উত্তর তৈরি হচ্ছে...','assistant');try{const res=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:prompt,language:lang})});const data=await res.json();if(!res.ok)throw new Error(data.error||'AI service unavailable');bubble.textContent=data.answer||'দুঃখিত, উত্তর পাওয়া যায়নি।'}catch(err){bubble.textContent='AI সংযোগ এখনো প্রস্তুত নয়। Admin-কে Cloudflare Pages-এর Environment Variables-এ AI_API_KEY এবং AI_MODEL সেট করতে হবে। নোট ও অন্যান্য টুল ব্যবহার করা যাবে।';console.warn(err)}}
$('#chat-form').addEventListener('submit',e=>{e.preventDefault();const p=$('#chat-prompt').value.trim();if(!p)return;$('#chat-prompt').value='';askAI(p)});
$$('.suggestions button').forEach(b=>b.addEventListener('click',()=>{showView('ai');askAI(b.textContent)}));
$('#question-count').textContent=questions;

if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
