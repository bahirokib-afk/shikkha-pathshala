// Cloudflare Pages Function: AI API key stays on the server, never in browser code.
export async function onRequestPost({ request, env }) {
  try {
    if (!env.AI_API_KEY) {
      return Response.json({ error: "AI is not configured. Add AI_API_KEY in Cloudflare Pages environment variables." }, { status: 503 });
    }
    const body = await request.json();
    const message = String(body.message || "").trim().slice(0, 8000);
    const language = body.language === "en" ? "English" : "Bengali";
    if (!message) return Response.json({ error: "Message is required." }, { status: 400 });

    // Configure an OpenAI-compatible endpoint and model in Cloudflare variables.
    const endpoint = env.AI_API_URL || "https://api.openai.com/v1/chat/completions";
    const model = env.AI_MODEL || "gpt-4o-mini";
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.AI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: `You are Shikkha Pathshala, a helpful and careful tutor for Bangladesh Diploma Engineering students. Reply in ${language}. Explain step by step, use simple language, show formulas when useful, and say when uncertain. Do not claim to replace teachers or official textbooks.` },
          { role: "user", content: message }
        ],
        temperature: 0.5
      })
    });
    const result = await upstream.json();
    if (!upstream.ok) {
      return Response.json({ error: result.error?.message || "AI provider returned an error." }, { status: 502 });
    }
    const answer = result.choices?.[0]?.message?.content;
    if (!answer) return Response.json({ error: "No answer returned by AI provider." }, { status: 502 });
    return Response.json({ answer });
  } catch (error) {
    return Response.json({ error: "Request could not be completed." }, { status: 500 });
  }
}
